package com.pjasoft.libraryapp.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.pjasoft.libraryapp.models.books
import com.pjasoft.libraryapp.screens.components.Header
import com.pjasoft.libraryapp.screens.components.PopularBook
import com.pjasoft.libraryapp.ui.theme.LibraryAppTheme

@Composable
fun BooksScreen(
    innerPadding: PaddingValues,
    navController: NavController
){
    val colors = MaterialTheme.colorScheme
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        //Header -- React -- Flutter -- SwiftUI
        // Lambdas!!
        item {
            Header(innerPadding,colors)
        }

        item{
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Libros Populares"
                )
                LazyRow(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(books){ book ->
                        PopularBook(
                            book = book,
                            onClick = {
                                navController.navigate("books/${book.id}")
                            }
                        )
                    }
                }
            }

        }

        items(books){ book->
            Text(
                text = book.title
            )
        }

    }
}

@Preview(
    showBackground = true,
    showSystemUi = true
)
@Composable
fun HomeScreenPreview(){
    LibraryAppTheme {
        BooksScreen(
            innerPadding = PaddingValues(10.dp),
            navController = rememberNavController()
        )
    }
}