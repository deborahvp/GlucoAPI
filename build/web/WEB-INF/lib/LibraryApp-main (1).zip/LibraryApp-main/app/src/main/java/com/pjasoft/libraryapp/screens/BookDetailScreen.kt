package com.pjasoft.libraryapp.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pjasoft.libraryapp.models.Book
import com.pjasoft.libraryapp.models.books
import com.pjasoft.libraryapp.ui.theme.LibraryAppTheme

@Composable
fun BookDetailScreen(
    innerPadding: PaddingValues,
    bookId : Int
){
    val book = books.firstOrNull { b-> b.id == bookId }
//    var book : Book? = null
//    for(b in books){
//        if(b.id == bookId){
//            book = b
//            break
//        }
//    }
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            text = book?.title ?: "Sin titulo"
        )
    }
}

@Preview
@Composable
fun BookDetailScreenPreview(){
    LibraryAppTheme {
        BookDetailScreen(
            innerPadding = PaddingValues(0.dp),
            bookId = 1
        )
    }
}