package com.pjasoft.libraryapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pjasoft.libraryapp.screens.BookDetailScreen
import com.pjasoft.libraryapp.screens.BooksScreen
import com.pjasoft.libraryapp.ui.theme.LibraryAppTheme
//Intents
// Compose Navigation 3
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LibraryAppTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val navController = rememberNavController()
                    NavHost(startDestination = "books", navController = navController){
                        composable(route = "books") {
                            BooksScreen(
                                innerPadding = innerPadding,
                                navController = navController
                            )
                        }
                        composable(
                            route = "books/{id}",
                            arguments = listOf(
                                navArgument("id"){
                                    type = NavType.IntType
                                    nullable = false
                                }
                            )
                        ) { backStack ->
                            //BackStack
                            val bookId = backStack.arguments?.getInt("id") ?: 0
                            BookDetailScreen(
                                innerPadding = innerPadding,
                                bookId = bookId
                            )
                        }
                    }

                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    LibraryAppTheme {
        Greeting("Android")
    }
}