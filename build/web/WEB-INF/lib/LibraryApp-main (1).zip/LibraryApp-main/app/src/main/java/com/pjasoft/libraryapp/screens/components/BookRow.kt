package com.pjasoft.libraryapp.screens.components

import androidx.compose.runtime.Composable
import com.pjasoft.libraryapp.models.Book

@Composable
fun BookRow(book: Book){

}