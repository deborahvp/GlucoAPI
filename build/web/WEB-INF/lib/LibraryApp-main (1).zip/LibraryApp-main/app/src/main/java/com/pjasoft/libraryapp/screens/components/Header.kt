package com.pjasoft.libraryapp.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp


@Composable
fun Header(innerPadding: PaddingValues, colors: ColorScheme){
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(bottomStart = 50.dp))
            .background(colors.primary)
            .padding(innerPadding)
            .padding(horizontal = 20.dp)
    )
    {
        Row(
            modifier = Modifier
                .fillMaxWidth()
        )
        {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Hola Juan",
                    color = colors.onPrimary
                )
                Text(
                    text = "Comencemos a leer",
                    color = colors.onPrimary
                )
            }

            IconButton(
                onClick = { },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(colors.tertiary)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "search",
                    tint = colors.onPrimary
                )
            }
            IconButton(
                onClick = { },
                modifier = Modifier
                    .padding(start = 15.dp)
                    .clip(CircleShape)
                    .background(colors.tertiary)

            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = "search",
                    tint = colors.onPrimary
                )
            }

        }
        Text(
            text = "Continuar Leyendo",
            modifier = Modifier.padding(top = 10.dp),
            color = colors.onPrimary
        )
        BookCard(colors)
    }
}