package com.pjasoft.libraryapp.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp


@Composable
fun BookCard(colors: ColorScheme){
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 10.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(colors.onPrimary)

    )
    {
        Box(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxHeight()
                .width(120.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Red)
        ) { }
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text= "Libro 1"
            )
            Text(
                text = "Autor",
                modifier = Modifier.weight(1f)
            )
            Row(
                modifier = Modifier
                    .padding(bottom = 10.dp)
                    .border(2.dp,colors.secondary,CircleShape)
                    .padding(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "menu",
                    tint = colors.secondary
                )
                Text(
                    text = "Leer"
                )
            }
        }
    }
}